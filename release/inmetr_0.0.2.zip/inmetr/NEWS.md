# inmetr 0.0.2

- fixed issue #1

- `import_bmep()` has a new argument `verbose` (default is TRUE - show messages).  